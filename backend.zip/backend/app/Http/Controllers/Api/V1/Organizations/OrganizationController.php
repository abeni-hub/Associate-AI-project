<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Organizations;

use App\Domains\AuditLogs\Actions\RecordAuditLogAction;
use App\Domains\Organizations\Models\Organization;
use App\Domains\Organizations\Services\OrganizationScopeService;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Organizations\CreateOrganizationRequest;
use App\Http\Requests\Api\V1\Organizations\UpdateOrganizationRequest;
use App\Http\Resources\Api\V1\OrganizationResource;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrganizationController extends Controller
{
    public function __construct(
        private readonly OrganizationScopeService $scopeService,
        private readonly RecordAuditLogAction $auditLogAction
    ) {}

    /**
     * List organizations with filtering, search, and hierarchy data scoping.
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user() ?? auth('sanctum')->user();

        if ($user && ! $user->hasPermission('organizations.view')) {
            return ApiResponse::error(
                message: 'You do not have permission to view organizations.',
                statusCode: 403
            );
        }

        $query = Organization::with(['type', 'parent.type'])
            ->withCount(['children', 'users']);

        // 1. Apply organization hierarchy data scoping (Super Admin = all; others = own + descendants; public = active)
        if ($user) {
            $this->scopeService->applyScope($query, $user, 'id', includeDescendants: true);
        } else {
            $query->where(function ($q) {
                $q->whereNull('status')
                    ->orWhereNotIn('status', ['inactive', 'suspended']);
            });
        }

        // 2. Filters
        if ($request->filled('search')) {
            $search = (string) $request->input('search');
            $like = DB::connection()->getDriverName() === 'pgsql' ? 'ilike' : 'like';
            $query->where(function ($q) use ($search, $like) {
                $q->where('name', $like, "%{$search}%")
                    ->orWhere('code', $like, "%{$search}%");
            });
        }

        if ($request->filled('type')) {
            $typeInput = strtolower(trim((string) $request->input('type')));
            $like = DB::connection()->getDriverName() === 'pgsql' ? 'ilike' : 'like';

            if ($typeInput === 'sub_city' || $typeInput === 'subcity') {
                $query->where(function ($q) use ($like) {
                    $q->whereHas('type', fn ($t) => $t->whereIn('code', ['sub_city', 'subcity']))
                        ->orWhere('name', $like, '%Sub-city%')
                        ->orWhere('name', $like, '%Sub City%')
                        ->orWhere('name', $like, '%Subcity%');
                })->where(function ($q) use ($like) {
                    $q->where('name', 'not '.$like, '%Bureau%')
                        ->where('name', 'not '.$like, '%Agency%');
                });
            } elseif ($typeInput === 'bureau' || $typeInput === 'agency') {
                $query->where(function ($q) use ($like) {
                    $q->whereHas('type', fn ($t) => $t->whereIn('code', ['bureau', 'agency']))
                        ->orWhere('name', $like, '%Bureau%')
                        ->orWhere('name', $like, '%Agency%');
                })->where(function ($q) use ($like) {
                    $q->where('name', 'not '.$like, '%Sub-city%')
                        ->where('name', 'not '.$like, '%Subcity%');
                });
            } else {
                $query->whereHas('type', fn ($q) => $q->where('code', $typeInput));
            }
        }

        if ($request->filled('type_id')) {
            $query->where('organization_type_id', (int) $request->input('type_id'));
        }

        if ($request->filled('parent_id')) {
            $parentId = $request->input('parent_id');
            if ($parentId === 'null' || $parentId === 'root') {
                $query->whereNull('parent_organization_id');
            } else {
                $query->where('parent_organization_id', (int) $parentId);
            }
        }

        if ($request->filled('status')) {
            $query->where('status', (string) $request->input('status'));
        }

        $perPage = min(max((int) $request->input('per_page', 15), 1), 100);
        $paginator = $query->orderBy('name')->paginate($perPage);

        return ApiResponse::paginated(
            paginator: $paginator,
            resourceClass: OrganizationResource::class,
            message: 'Organizations retrieved successfully.'
        );
    }

    /**
     * Get the full organizational hierarchy tree scoped to the user.
     */
    public function tree(Request $request): JsonResponse
    {
        $user = $request->user() ?? auth('sanctum')->user();

        if ($user && ! $user->hasPermission('organizations.view')) {
            return ApiResponse::error(
                message: 'You do not have permission to view organizations.',
                statusCode: 403
            );
        }

        if ($user && ! $user->isSuperAdmin()) {
            // Start from the user's root in their scope
            $userOrg = $user->organization ?? Organization::find($user->organization_id);

            if (! $userOrg) {
                $roots = collect();
            } else {
                $roots = Organization::where('id', $userOrg->id)
                    ->with(['type', 'children.type', 'children.children.type'])
                    ->withCount(['children', 'users'])
                    ->get();
            }
        } else {
            // Super Admin or public citizen discovery: Root organizations with nested descendants
            $query = Organization::whereNull('parent_organization_id');
            if (! $user) {
                $query->where('status', 'active');
            }
            $roots = $query
                ->with(['type', 'children.type', 'children.children.type'])
                ->withCount(['children', 'users'])
                ->orderBy('name')
                ->get();
        }

        return ApiResponse::success(
            data: OrganizationResource::collection($roots),
            message: 'Organization hierarchy tree retrieved successfully.'
        );
    }

    /**
     * Show a single organization profile.
     */
    public function show(Request $request, Organization $organization): JsonResponse
    {
        $user = $request->user();

        if (! $this->scopeService->canAccessOrganization($user, $organization, allowDescendants: true)) {
            return ApiResponse::error(
                message: 'Forbidden. You do not have permission to view this organization.',
                statusCode: 403
            );
        }

        $organization->load(['type', 'parent.type', 'children.type'])
            ->loadCount(['children', 'users']);

        return ApiResponse::success(
            data: new OrganizationResource($organization),
            message: 'Organization retrieved successfully.'
        );
    }

    /**
     * Store a newly created organization.
     */
    public function store(CreateOrganizationRequest $request): JsonResponse
    {
        $data = $request->validated();
        $data['logo_path'] = $request->file('logo')->store('organizations/logos', 'public');
        unset($data['logo']);
        $data['status'] = $data['status'] ?? 'active';

        $organization = Organization::create($data);
        $organization->load(['type', 'parent.type']);

        $this->auditLogAction->execute(
            action: 'created',
            entity: $organization,
            actor: $request->user(),
            newValues: $organization->toArray(),
            request: $request
        );

        return ApiResponse::success(
            data: new OrganizationResource($organization),
            message: 'Organization created successfully.',
            statusCode: 201
        );
    }

    /**
     * Update an existing organization.
     */
    public function update(UpdateOrganizationRequest $request, Organization $organization): JsonResponse
    {
        $user = $request->user();

        if (! $this->scopeService->canManageOrganization($user, $organization)) {
            return ApiResponse::error(
                message: 'Forbidden. You do not have permission to modify this organization.',
                statusCode: 403
            );
        }

        $oldValues = $organization->toArray();
        $organization->update($request->validated());
        $organization->load(['type', 'parent.type']);

        $this->auditLogAction->execute(
            action: 'updated',
            entity: $organization,
            actor: $user,
            oldValues: $oldValues,
            newValues: $organization->toArray(),
            request: $request
        );

        return ApiResponse::success(
            data: new OrganizationResource($organization),
            message: 'Organization updated successfully.'
        );
    }

    /**
     * Soft-delete an organization.
     */
    public function destroy(Request $request, Organization $organization): JsonResponse
    {
        $user = $request->user();

        if (! $this->scopeService->canManageOrganization($user, $organization)) {
            return ApiResponse::error(
                message: 'Forbidden. You do not have permission to delete this organization.',
                statusCode: 403
            );
        }

        // Integrity Rule: Cannot delete an organization that has active child organizations
        if ($organization->children()->exists()) {
            return ApiResponse::error(
                message: 'Cannot delete organization because it has existing child units. Reassign or remove child units first.',
                statusCode: 422
            );
        }

        // Integrity Rule: Cannot delete an organization that has active users assigned
        if ($organization->users()->exists()) {
            return ApiResponse::error(
                message: 'Cannot delete organization because active users are assigned to it. Reassign users first.',
                statusCode: 422
            );
        }

        $oldValues = $organization->toArray();
        $organization->delete();

        $this->auditLogAction->execute(
            action: 'deleted',
            entity: $organization,
            actor: $user,
            oldValues: $oldValues,
            request: $request
        );

        return ApiResponse::success(
            data: null,
            message: 'Organization deleted successfully.'
        );
    }
}

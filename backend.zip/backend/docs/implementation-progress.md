# Implementation Progress Tracking

## Phase Status Summary

| Phase | Description | Status | Completion Date |
| :--- | :--- | :--- | :--- |
| **Phase 1** | Laravel Project Setup and Foundation | **Completed & Verified** | 2026-10-24 |
| **Phase 2** | Database Architecture and Foundation | **Completed & Verified** | 2026-10-24 |
| **Phase 3** | Authentication (Sanctum SPA & API Tokens) | **Completed & Verified** | 2026-10-25 |
| **Phase 4** | Authorization & Organization Data Scope | **Completed & Verified** | 2026-10-25 |
| **Phase 5** | Organization and User Management | **Completed & Verified** | 2026-10-25 |
| **Phase 6** | Services, Subservices, and Required Documents | **Completed & Verified** | 2026-10-25 |
| **Phase 7** | Room-by-Room Service Instructions | **Completed & Verified** | 2026-10-26 |
| **Phase 8** | News and Events Management | **Completed & Verified** | 2026-10-26 |
| **Phase 9** | Citizen Feedback and QR Code Management | **Completed & Verified** | 2026-10-26 |
| **Phase 10** | Dashboards and Reporting | **Completed & Verified** | 2026-10-27 |
| **Phase 11** | Super Admin Landing Page CMS Domain | **Completed & Verified** | 2026-10-29 |
| **V3 Phase 1** | Database Migrations (v3 Architecture & Client Feedback) | **Completed & Verified** | 2026-11-02 |
| **V3 Phase 2** | Eloquent Models & DDD Entities | **Completed & Verified** | 2026-11-02 |
| **V3 Phase 3** | Database Seeders & Role Mapping | **Completed & Verified** | 2026-11-02 |
| **V3 Phase 4** | Scoped RBAC, Business Services & Navigation API | **Completed & Verified** | 2026-11-02 |
| **V3 Phase 5** | Automated Integration Tests & Verification (226 Tests) | **Completed & Verified** | 2026-11-02 |
| **V3 Phase 6** | Frontend Portal Dynamic Navigation & System Documentation | **Completed & Verified** | 2026-11-02 |

---

## Phase 3 Detail — Authentication (Sanctum SPA)

### Completed Milestones
- [x] Configured stateful first-party React SPA authentication via Laravel Sanctum session cookies.
- [x] Implemented authentication endpoints under `/api/v1/auth`:
  - `POST /api/v1/auth/login` (rate-limited, generic credentials matching, status check, session regeneration)
  - `POST /api/v1/auth/logout` (session invalidation, CSRF regeneration, transient token safety)
  - `GET /api/v1/auth/me` (retrieves authenticated profile with organization and role context)
  - `PUT /api/v1/auth/change-password` (validates current password, clears forced password change flag)
  - `POST /api/v1/auth/forgot-password` (anti-enumeration generic response, SPA reset URL mapping)
  - `POST /api/v1/auth/reset-password` (token validation and password update)
- [x] Configured dedicated rate limiters:
  - `login`: 5 attempts per minute per identifier/IP combo with custom 429 response.
  - `password-reset`: 5 requests per minute with anti-abuse protection.
- [x] Implemented `EnsureAccountIsActive` middleware:
  - Enforces account status (`active` vs `inactive` / `suspended`).
  - Performs live database status verification ensuring mid-session deactivations immediately revoke access.
- [x] Implemented `UserResource` ensuring passwords and sensitive secrets are never leaked.
- [x] Implemented domain services and actions (`AuthenticationService`, `ChangePasswordAction`, `ResetPasswordAction`).
- [x] Comprehensive automated test suites executed on PostgreSQL:
  - `AuthenticationTest`: 12 tests, 38 assertions (100% passed).
  - `AuthSecurityTest`: 2 tests, 6 assertions (100% passed).
  - Overall test suite: 39 tests, 133 assertions (100% passed).
- [x] Code style verified with Laravel Pint (`100% passed`).
- [x] Updated documentation (`docs/api.md`, `docs/implementation-progress.md`).

---

## Phase 4 Detail — Authorization & Organization Data Scope

### Completed Milestones
- [x] Implemented `EnsureHasPermission` middleware:
  - Enforces route-level permission checks (e.g., `permission:roles.view`, `permission:roles.manage`).
  - Grants platform Super Admins implicit bypass across all permission checks.
  - Returns unified error envelope with HTTP 403 Forbidden on authorization failure.
  - Registered as `permission` alias in `bootstrap/app.php`.
- [x] Configured dynamic Laravel Gates in `AppServiceProvider`:
  - `Gate::before`: Automatically permits Super Admin platform-wide.
  - `Gate::after`: Dynamically resolves arbitrary permission keys against the user's role permissions.
- [x] Implemented `OrganizationScopeService`:
  - Hierarchy-aware data scoping engine for Sub-Cities, Woredas, and Bureaus.
  - `getAllowedOrganizationIds()`: Returns `null` for global Super Admins; returns own ID or own + recursive descendant IDs for hierarchy levels.
  - `canAccessOrganization()`: Validates whether a user can read a given target organization based on hierarchy boundaries.
  - `canManageOrganization()`: Validates administrative mutations within permitted hierarchy trees.
  - `applyScope()`: Automatically applies `whereIn('organization_id', ...)` filters to Eloquent queries.
- [x] Created `HasOrganizationScope` Eloquent Trait:
  - Provides `scopeForUserOrganization(Builder $query, User $user, bool $includeDescendants = false)` on models.
- [x] Implemented Roles & Permissions API endpoints under `/api/v1`:
  - `GET /api/v1/roles` (lists all roles with permissions count, protected by `permission:roles.view`).
  - `GET /api/v1/roles/{role}` (retrieves role and complete assigned permissions list).
  - `PUT /api/v1/roles/{role}/permissions` (syncs permissions, protects Super Admin system role).
  - `GET /api/v1/permissions` (lists all permissions ordered by group and name).
- [x] Created API Form Requests and Resources:
  - `SyncRolePermissionsRequest`
  - `RoleResource`, `PermissionResource`
- [x] Developed comprehensive test suites:
  - `OrganizationScopeServiceTest`: Verifies Super Admin global access, Sub-City descendant inheritance, Woreda isolation from parent/sibling trees, and Staff strict isolation.
  - `PermissionMiddlewareTest`: Verifies route protection, 401 unauthenticated, 403 forbidden, and Super Admin bypass.
  - `RolePermissionApiTest`: Verifies endpoints, payload contracts, permission sync, and Super Admin immutability.
- [x] Updated specifications in `docs/api.md` and `docs/implementation-progress.md`.

---

## Phase 5 Detail — Organization and User Management

### Completed Milestones
- [x] Implemented `RecordAuditLogAction`:
  - Structured, sanitized audit logging for administrative mutations (`created`, `updated`, `deleted`, `password_reset`).
  - Automatically records client IP, User-Agent, actor ID, and organization context.
  - Automatically redacts sensitive fields (passwords, tokens).
- [x] Implemented Organization Management Endpoints:
  - `GET /api/v1/organization-types`: List government classification tiers with allowed parent rules.
  - `GET /api/v1/organizations`: Scoped and filtered list of organizations (search by name/code, filter by type, parent, status).
  - `GET /api/v1/organizations/tree`: Complete hierarchical tree structure rooted in user's scope.
  - `GET /api/v1/organizations/{id}`: Detailed profile with parent, children, and metrics.
  - `POST /api/v1/organizations`: Create organization with hierarchy rule verification (`canHaveParent`) and administrative tree scope checks.
  - `PUT /api/v1/organizations/{id}`: Update organization details with circular hierarchy prevention.
  - `DELETE /api/v1/organizations/{id}`: Soft delete with strict safety checks (rejects deletion if child units or active users exist).
- [x] Implemented User Management Endpoints:
  - `GET /api/v1/users`: List users filtered by role, organization, and status, strictly scoped to caller's administrative hierarchy.
  - `GET /api/v1/users/{id}`: Single user profile with organization and role context.
  - `POST /api/v1/users`: Provision administrative and staff users with password hashing, `must_change_password` enforcement, and hierarchy assignment restrictions.
  - `PUT /api/v1/users/{id}`: Update user profile, status, and role with last Super Admin safety protections.
  - `DELETE /api/v1/users/{id}`: Soft delete user accounts with token revocation; self-deletion and last Super Admin deletion protections.
  - `POST /api/v1/users/{id}/reset-password`: Administrative password reset with immediate token revocation and forced change flag.
- [x] Created Form Requests and API Resources:
  - `CreateOrganizationRequest`, `UpdateOrganizationRequest`
  - `CreateUserRequest`, `UpdateUserRequest`, `AdminResetPasswordRequest`
  - `OrganizationResource`, `OrganizationTypeResource`, `UserResource`
- [x] Developed comprehensive automated test suites:
  - `OrganizationManagementTest`: Type listing, scoped organization lists, root organization Super Admin restrictions, hierarchy validation, tree endpoint, and integrity rules against deleting organizations with child units or assigned users.
  - `UserManagementTest`: User hierarchy scoping, Super Admin creation restrictions, self-deletion prevention, last Super Admin demotion/deletion prevention, administrative password reset flow, and audit logging.
- [x] Updated documentation in `docs/api.md` (Sections 5 and 6) and `docs/implementation-progress.md`.

---

## Phase 6 Detail — Services, Subservices, and Required Documents

### Completed Milestones
- [x] Database Schema & Migrations:
  - `services` table with self-referencing `parent_id`, code, name, description, eligibility criteria, fees (`fee_amount`, `fee_currency`), `estimated_duration_minutes`, `is_active`, and metadata.
  - `documents` table cataloging required documentation (code, name, description, sample/template URLs, file format constraints, `max_file_size_kb`, `is_active`).
  - `service_documents` pivot table connecting services to required documents with `is_mandatory`, `order_column`, and contextual `notes`.
  - `organization_services` pivot table registering service availability per government tier/office with custom instructions and contact details.
- [x] Domain Models & Architecture:
  - `App\Domains\Services\Models\Service`: Self-referencing hierarchy (`parent`, `subservices`), `requiredDocuments`, `offeringOrganizations`, `scopeActive`, `scopeMasterOnly`, `scopeSubservicesOnly`.
  - `App\Domains\Documents\Models\Document`: Relationship to `services`, `scopeActive`.
- [x] Citizen Public Discovery Endpoints:
  - `GET /api/v1/services`: Filterable catalog (search, master-only, subservices-only, organization-specific, active only).
  - `GET /api/v1/services/{id_or_code}`: Full service profile including subservices, offering organizations, and linked required documents.
  - `GET /api/v1/documents`: Public catalog of required documents and forms.
  - `GET /api/v1/documents/{id_or_code}`: Single document requirement specifications.
- [x] Administrative Management Endpoints (Protected by Sanctum & Permissions):
  - `POST /api/v1/services`: Create service with strict 2-level nesting limit (preventing deep chains beyond Master -> Subservice).
  - `PUT /api/v1/services/{id}`: Update service metadata with circular hierarchy prevention.
  - `DELETE /api/v1/services/{id}`: Soft delete service with subservice cascades.
  - `POST /api/v1/services/{service}/documents`: Sync required documents with pivot attributes (`is_mandatory`, `notes`, `order_column`).
  - `POST /api/v1/services/{service}/organizations`: Sync offering government offices with localized instructions.
  - `POST /api/v1/documents`: Create catalog document requirement.
  - `PUT /api/v1/documents/{id}`: Update document specifications.
  - `DELETE /api/v1/documents/{id}`: Soft delete document requirement.
- [x] Form Requests & Validation:
  - `CreateServiceRequest`, `UpdateServiceRequest`, `SyncServiceDocumentsRequest`, `SyncOfferingOrganizationsRequest`.
  - `CreateDocumentRequest`, `UpdateDocumentRequest`.
- [x] Automated Tests on PostgreSQL:
  - `ServiceCatalogTest`: Public listing, filtering, search, and detail lookup by slug/code.
  - `ServiceManagementTest`: Admin creation, 2-level hierarchy restriction, updating, and syncing document pivots.
  - `RequiredDocumentTest`: Public document catalog and admin document CRUD.
- [x] Documentation updated in `docs/api.md` (Sections 7 & 8) and `docs/implementation-progress.md`.

---

## Phase 7 Detail — Room-by-Room Service Instructions (Service Steps)

### Completed Milestones
- [x] Database Schema & Migrations:
  - `service_steps` table with `service_id` (foreign key to `services`), nullable `organization_id` (for location-specific office instructions), `step_number`, `title`, `instruction`, `room_number`, `floor`, `building`, `department_name`, `responsible_title`, `estimated_duration_minutes`, and `is_active`.
  - Indexed for fast ordering and filtering: `['service_id', 'step_number']`, `['service_id', 'organization_id']`, and `is_active`.
- [x] Domain Models & Eloquent Architecture:
  - `App\Domains\Services\Models\ServiceStep`: Belongs to `Service`, optional belongs to `Organization`, scopes for `scopeActive`, `scopeOrdered`, and `scopeForOrganization`.
  - `App\Domains\Services\Models\Service`: Added `steps()` relationship with sequential ordering.
  - `ServiceResource`: Eager-loaded `steps` and `steps_count`, alongside document requirements and offering units.
- [x] Public Citizen Discovery Endpoints:
  - `GET /api/v1/services/{service_id_or_code}/steps`: Ordered navigation checklist for a service with optional `organization_id` office filter.
  - `GET /api/v1/services/{service_id_or_code}/steps/{step_id}`: Single room step instructions.
  - `GET /api/v1/services/{service_id_or_code}`: Service detail endpoint automatically embeds the full room-by-room step journey.
- [x] Administrative Management Endpoints (Protected by `auth:sanctum` + `permission:service_steps.manage`):
  - `POST /api/v1/services/{service_id_or_code}/steps`: Create a new room instruction (auto-calculates next `step_number` if omitted).
  - `PUT /api/v1/services/{service_id_or_code}/steps/{step_id}`: Update step instructions, room number, floor, or duration.
  - `DELETE /api/v1/services/{service_id_or_code}/steps/{step_id}`: Delete a room step with organizational boundary checks.
  - `POST /api/v1/services/{service_id_or_code}/steps/reorder`: Atomic batch step reordering with database transaction.
- [x] Form Requests & Validation:
  - `CreateServiceStepRequest`: Validates step attributes and organizational hierarchy scope (`OrganizationScopeService::canManageOrganization`).
  - `UpdateServiceStepRequest`: Partial update validation and organizational permission enforcement.
  - `ReorderServiceStepsRequest`: Validates step ID existence and sequential numbering.
- [x] Realistic Sample Data Seeder:
  - `Database\Seeders\ServiceSeeder`: Seeds master services, subservices, documents, and a 4-step room-by-room journey for Birth Certificate Issuance.
- [x] Comprehensive Automated Tests:
  - `Tests\Feature\Api\V1\Services\ServiceStepTest`: 9 tests, 38 assertions (100% passed).
  - All 21 tests for Services, Steps, and Documents pass with 103 assertions.
- [x] Live Server Verification:
  - Verified `GET http://127.0.0.1:8000/api/v1/services/birth-certificate/steps` returning all 4 steps.
  - Verified `GET http://127.0.0.1:8000/api/v1/services/birth-certificate` returning steps embedded with counts.
- [x] Documentation updated in `docs/api.md` (Section 9) and `docs/implementation-progress.md`.

---

## Phase 10 Detail — Dashboards and Reporting

### Completed Milestones
- [x] Domain Architecture:
  - `App\Domains\Dashboard\Services\DashboardMetricsService`: Role-aware and organization-scoped metrics and analytics calculation service across Organizations, Users, Services, Documents, Feedback, News, and AuditLogs.
- [x] Administrative Dashboard & Reporting Endpoints (Protected by `auth:sanctum` + `account.active` + `permission:dashboard.view`):
  - `GET /api/v1/dashboard/overview`: High-level KPI overview across all platform domains, strictly scoped to caller's administrative hierarchy (Super Admin global; Sub-City, Woreda, Bureau hierarchy-scoped).
  - `GET /api/v1/dashboard/stats`: Functional alias for overview.
  - `GET /api/v1/dashboard/reports/feedback`: Detailed feedback metrics, complaint percentages, type distribution, top feedback receiving organizations, and recent entries with date and organization filters.
  - `GET /api/v1/dashboard/reports/services`: Service catalog delivery metrics, duration averages, fee analysis, and top offered services.
  - `GET /api/v1/dashboard/reports/organizations`: Hierarchical coverage, administrative level distribution (Sub-City, Woreda, Bureau), root vs child ratio, and top staffing units.
  - `GET /api/v1/dashboard/recent-activity`: Scoped administrative audit trails with entity, action, actor, and organization details.
- [x] Form Requests & Scope Validation:
  - `FeedbackReportRequest`: Validates date range constraints and validates that optional `organization_id` filters belong to the user's accessible hierarchy (`OrganizationScopeService::canAccessOrganization`).
  - `RecentActivityRequest`: Validates limit (1-50), entity type, and action filters.
- [x] Transport Layer:
  - `App\Http\Controllers\Api\V1\Dashboard\DashboardController`: Handles overview, feedback, services, organizations, and recent activity routes adhering to the unified `ApiResponse::success(...)` envelope.
- [x] Comprehensive Automated Tests on PostgreSQL:
  - `Tests\Feature\Api\V1\Dashboard\DashboardApiTest`: 11 tests, 46 assertions (100% passed).
  - Tests 401 unauthenticated access, 403 inactive account access, Super Admin global scope, Sub-City Admin hierarchy scope, Woreda Admin isolation, stats alias, feedback filtering and foreign organization rejection, services report, organizations report, and recent activity scoping.
- [x] Overall Backend Test Suite:
  - 108 tests, 767 assertions (100% passed).
- [x] Code Quality:
  - Formatted and verified with Laravel Pint (`vendor/bin/pint`).
- [x] Documentation updated in `docs/api.md` (Section 11) and `docs/implementation-progress.md`.

---

## Phase 11 Detail — Super Admin Landing Page CMS Domain

### Completed Milestones
- [x] Database Schema & Migration:
  - Created `landing_page_configs` table with `version`, `is_published`, `content` (jsonb/json), `updated_by` foreign key, and unique index on `['version']`.
- [x] Domain-Driven Design (`app/Domains/Cms/`):
  - Model: `LandingPageConfig` with array/boolean casts, `updatedBy` relation, and `current()` static helper.
  - Actions:
    - `GetLandingPageCmsAction`: Active published configuration retrieval with default fallback.
    - `UpdateLandingPageCmsAction`: Transactional update, `updated_by` association, and `RecordAuditLogAction` audit logging.
    - `UploadCmsImageAction`: Validates image, stores on `public` disk under `cms/hero/`, and returns absolute reachable URL.
  - Support: `DefaultLandingPageContent` defining the complete 8-section payload matching citizen and portal specifications.
- [x] Transport & HTTP Layer:
  - `UpdateLandingPageCmsRequest`: Comprehensive validation rules for all 8 sections (`announcement`, `hero`, `quickSearch`, `serviceGuide`, `journey`, `newsEvents`, `feedback`, `footer`).
  - `UploadCmsImageRequest`: File validation for jpeg, png, jpg, webp up to 5MB.
  - `CmsController`: Public `show`, protected `update`, and protected `uploadImage` handlers using unified `ApiResponse`.
- [x] RBAC & Routes:
  - Seeded permission `cms.manage` in `PermissionSeeder` and granted to `super_admin`.
  - Registered `GET /api/v1/cms/landing-page` (public).
  - Registered `PUT /api/v1/cms/landing-page` and `POST /api/v1/cms/upload-image` (`auth:sanctum`, `account.active`, `permission:cms.manage`).
- [x] Automated Feature Tests:
  - `Tests\Feature\Api\V1\Cms\LandingPageCmsTest`: 9 tests, 113 assertions (100% passed).
- [x] Full Backend Test Suite:
  - 201 tests, 1,283 assertions (100% passed).

---

## Client Revision V3 Architecture Overhaul

### V3 Phase 1 — Database Migrations (Schema Modernization)
- [x] **Dynamic Sidebar Navigation**:
  - `navigation_items`: Flat single-tier items (`id`, `label`, `route`, `icon`, `display_order`, `is_active`, `required_permission`). Dropped `parent_id` per client specifications.
  - `role_navigation_items`: Many-to-many pivot table mapping navigation items to authorized system roles (`role_id`, `navigation_item_id`).
- [x] **Scoped RBAC & Granular Permission CRUD**:
  - Added `scope_level` integer column to `roles` table (1: Global Super Admin, 2: Sub-City Admin, 3: Woreda Admin, 4: Bureau Admin, 5: Staff).
  - Enhanced `role_permissions` pivot with granular CRUD capability flags: `can_create`, `can_read`, `can_update`, `can_delete`.
- [x] **Simplified Feedback Privacy**:
  - Dropped `email` column from `feedbacks` table to respect citizen privacy and prevent personal identification leakage. Feedback submissions retain optional phone contact.
- [x] **Standardized Service Catalog**:
  - Dropped `specific_instructions` from `organization_services` pivot table to preserve central municipal standardization across offices.
- [x] **Standalone Organization QR Posters**:
  - Created standalone `qr_codes` table (`id`, `organization_id`, `code`, `label`, `target_url`, `scan_count`, `last_scanned_at`, `status`). Removed `service_id` to allow general organization arrival checkpoints.
- [x] **Community Events & Multi-Photo Gallery**:
  - Created `events` table (`id`, `organization_id`, `title`, `description`, `location_name`, `event_date`, `end_date`, `audience`, `status`).
  - Created `event_images` 1:N photo gallery table (`id`, `event_id`, `image_url`, `caption`, `order_column`).
- [x] **Forensic Audit Logging & Telemetry**:
  - Enhanced `audit_logs` table: Added `status` (`success`, `failure`), `status_code` integer, `request_payload` (jsonb/json), and `response_payload` (jsonb/json) with automatic password and token masking.
  - Dropped redundant `organization_id` column from `audit_logs` (resolved dynamically via `user->organization`).
- [x] **Removed Statutory Hierarchy Pivot**:
  - Dropped `organization_type_allowed_parents` table in favor of integer rank statutory hierarchy (`$parentType->level < $this->level`).

---

### V3 Phase 2 — Eloquent Models & DDD Entities
- [x] Implemented `App\Domains\Navigation\Models\NavigationItem`:
  - Belongs-to-many relationship with `Role` through `role_navigation_items`.
  - Scopes: `scopeActive`, `scopeOrdered`.
- [x] Implemented `App\Domains\QrCodes\Models\QrCode`:
  - Belongs-to relationship with `Organization`.
  - Scopes: `scopeActive`, helper `recordScan()`.
- [x] Implemented `App\Domains\Events\Models\Event` and `EventImage`:
  - 1:N relationship with `EventImage` (`images`).
  - Belongs-to relationship with `Organization`.
  - Scopes: `scopePublished`, `scopeUpcoming`.
- [x] Updated `Role` and `Permission` models:
  - Role includes `scope_level` cast and helper `canManageScope(Role $otherRole)`.
  - `role_permissions` pivot equipped with `can_create`, `can_read`, `can_update`, `can_delete` booleans.
- [x] Updated `Organization` and `OrganizationType`:
  - `OrganizationType` statutory rank comparison: child types must have higher level integers than parent types (`$parentType->level < $this->level`).
  - Circular hierarchy prevention on saved models (`$this->exists && $this->id !== null`).
- [x] Updated `AuditLog`:
  - Casts for `status_code`, `request_payload` (array), and `response_payload` (array).

---

### V3 Phase 3 — Database Seeders & Role Mapping
- [x] `NavigationItemSeeder`: Seeded all 8 standard navigation items (`Overview`, `Sub-cities`, `Accounts`, `Feedback`, `Services`, `Routes`, `QR Poster`, `CMS`) and mapped them to their authorized roles in `role_navigation_items`.
- [x] `RoleSeeder`: Updated with statutory `scope_level` values and granular CRUD permissions.
- [x] `QrCodeSeeder`: Seeded sample organization QR posters for administrative offices.
- [x] `EventSeeder`: Seeded upcoming civic events with multi-photo gallery entries.
- [x] `OrganizationTypeSeeder`: Cleaned up to reflect statutory hierarchy levels without the allowed parents pivot.
- [x] `DatabaseSeeder`: Integrated all new seeders into master seeding pipeline.

---

### V3 Phase 4 — Scoped RBAC, Business Services & Navigation API
- [x] **Dynamic Sidebar Navigation**:
  - Implemented `GetSidebarNavigationAction` delivering authorized sidebar menu items filtered by user role and ordered strictly by `display_order`.
  - Implemented `NavigationController` with `GET /api/v1/navigation/sidebar`.
- [x] **QR Code Poster Management & Public Scanning**:
  - `GET /api/v1/qr-codes`: Scoped listing of posters within actor's hierarchy.
  - `GET /api/v1/qr-codes/{qrCode}`: Poster detail retrieval.
  - `POST /api/v1/qr-codes`: Poster creation within administrative hierarchy.
  - `POST /api/v1/qr-codes/{code}/scan`: Public scan counter increment and target URL resolution.
- [x] **Civic Events & Photo Gallery**:
  - `GET /api/v1/events`: Public listing of upcoming published events or scoped admin management.
  - `GET /api/v1/events/{event}`: Single event profile with multi-image gallery.
  - `POST /api/v1/events`: Event creation with atomic gallery photo persistence.
  - `DELETE /api/v1/events/{event}`: Event deletion cascading to all gallery images.
- [x] **Privilege Escalation Protection**:
  - `CreateUserRequest` and `UpdateUserRequest` enforce `canManageScope` validation: callers cannot create or assign users with equal or higher administrative rank (`scope_level`).

---

### V3 Phase 5 — Automated Feature Tests & Verification
- [x] Developed comprehensive feature integration test suite `Tests\Feature\Api\V1\Phase5EndToEndIntegrationTest`:
  - Dynamic navigation endpoint security and role-specific item filtering.
  - Scope level hierarchy and privilege escalation prevention.
  - Granular CRUD permission pivot capabilities.
  - Standalone QR poster creation, hierarchy scoping, and public scanning.
  - Civic event creation with multiple gallery photos and cascade deletion.
  - Audit log forensic JSON payload capture, status code recording, and sensitive secret masking.
- [x] Full Test Suite Execution:
  - **226 tests passed, 1,445 assertions, 0 errors, 0 failures**.

---

### V3 Phase 6 — Frontend Portal Dynamic Navigation & System Documentation
- [x] **Frontend Portal Integration (`portal/src/App.jsx`)**:
  - Connected `Sidebar` to `GET /api/v1/navigation/sidebar` when authenticated.
  - Implemented `normalizeIconName` supporting Lucide and backend icon identifiers (`LayoutDashboard`, `Building2`, `Users`, `MessageSquareQuote`, `Briefcase`, `MapPin`, `QrCode`, `FileText`, `HomeIcon`, `BuildingOffice2Icon`, `ShieldCheckIcon`) mapped to SVG symbols.
  - Integrated real API authentication in `Login` with automatic bearer token storage.
  - Seamless fallback to static `NAV[role]` when offline or in demo preview mode.
- [x] **System Documentation Updates**:
  - `backend/docs/database-design.md`: Full 21-table schema, Mermaid ERD, documentation of removed pivots and added forensic JSON audit log columns.
  - `backend/docs/architecture.md`: Modular monolith DDD layout (`Cms`, `Navigation`, `Events`, `QrCodes`), statutory hierarchy rules, privilege escalation protection, and dynamic sidebar navigation.
  - `backend/docs/api.md`: Added Sections 13 (Dynamic Navigation), 14 (QR Codes), 15 (Civic Events), renumbered Section 16 (Landing Page CMS), and removed `email` from feedback endpoints.
  - `backend/docs/implementation-progress.md`: Marked all v3 modernization phases completed and verified.





